// Configuration
const CONFIG = {
    storeName: "Audaz",
    storeAddress: "San Martín 3062, Santa Fe, Argentina",
    storeCoordinates: {
        lat: -31.6333,
        lng: -60.7000
    },
    shipping: {
        ratePerKm: 500,
        freeShippingThreshold: 100000 // Free shipping over $100k
    },
    googleMapsApiKey: "AIzaSyBdqfaSrmKKlfLOY0wdoof4bETPK_qP7dY" // You'll need to replace this with your own key
};
