// Checkout state
let cart = JSON.parse(localStorage.getItem('audaz_cart')) || [];
let customerData = {};
let shippingCost = 0;
let selectedPaymentMethod = null;

// Initialize checkout
document.addEventListener('DOMContentLoaded', () => {
    if (cart.length === 0) {
        alert('Tu carrito está vacío');
        window.location.href = 'index.html';
        return;
    }

    renderCartSummary();
    calculateSubtotal();
});

// Render cart summary
function renderCartSummary() {
    const cartSummary = document.getElementById('cart-summary');

    cartSummary.innerHTML = cart.map(item => `
        <div class="flex gap-3 pb-3 border-b">
            <img src="${item.image}" alt="${item.name}" class="w-16 h-20 object-cover">
            <div class="flex-1">
                <p class="font-medium text-sm">${item.name}</p>
                <p class="text-xs text-gray-600">Talle: ${item.selectedSize}</p>
                <p class="text-sm">Cantidad: ${item.quantity}</p>
            </div>
            <p class="font-bold">$${(item.price * item.quantity).toLocaleString()}</p>
        </div>
    `).join('');
}

// Calculate subtotal
function calculateSubtotal() {
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    document.getElementById('subtotal').textContent = `$${subtotal.toLocaleString()}`;
    document.getElementById('total-step1').textContent = `$${subtotal.toLocaleString()}`;
    return subtotal;
}

// Toggle delivery fields
function toggleDeliveryFields() {
    const deliveryMethod = document.querySelector('input[name="delivery"]:checked').value;
    const shippingFields = document.getElementById('shipping-fields');
    const shippingCalc = document.getElementById('shipping-calculation');
    const shippingRow = document.getElementById('shipping-row-summary');

    if (deliveryMethod === 'shipping') {
        shippingFields.classList.remove('hidden');
        // Make shipping fields required
        document.getElementById('street').required = true;
        document.getElementById('streetNumber').required = true;
        document.getElementById('city').required = true;
    } else {
        shippingFields.classList.add('hidden');
        shippingCalc.classList.add('hidden');
        if (shippingRow) shippingRow.classList.add('hidden');
        shippingCost = 0;
        // Remove required from shipping fields
        document.getElementById('street').required = false;
        document.getElementById('streetNumber').required = false;
        document.getElementById('city').required = false;

        // Update total
        const subtotal = calculateSubtotal();
        document.getElementById('total-step1').textContent = `$${subtotal.toLocaleString()}`;
    }
}

// Calculate shipping cost using Google Maps Distance Matrix API
async function calculateShipping() {
    const street = document.getElementById('street').value;
    const streetNumber = document.getElementById('streetNumber').value;
    const city = document.getElementById('city').value;

    if (!street || !streetNumber || !city) {
        return 0;
    }

    const destination = `${street} ${streetNumber}, ${city}, Argentina`;

    // For demo purposes, we'll use a simple distance calculation
    // In production, you would use Google Maps Distance Matrix API
    // const response = await fetch(`https://maps.googleapis.com/maps/api/distancematrix/json?origins=${CONFIG.storeAddress}&destinations=${destination}&key=${CONFIG.googleMapsApiKey}`);

    // Simulated distance (in real app, this would come from Google Maps API)
    const simulatedDistanceKm = Math.floor(Math.random() * 20) + 5; // Random between 5-25 km
    const calculatedCost = simulatedDistanceKm * CONFIG.shipping.ratePerKm;

    // Display shipping info
    document.getElementById('distance-text').textContent = `Aproximadamente ${simulatedDistanceKm} km desde nuestro local`;
    document.getElementById('shipping-cost').textContent = `$${calculatedCost.toLocaleString()}`;
    document.getElementById('shipping-calculation').classList.remove('hidden');

    shippingCost = calculatedCost;

    // Update sticky summary
    const shippingRow = document.getElementById('shipping-row-summary');
    const shippingSummary = document.getElementById('shipping-summary');
    if (shippingRow && shippingSummary) {
        shippingRow.classList.remove('hidden');
        shippingSummary.textContent = `$${calculatedCost.toLocaleString()}`;
    }

    // Update total
    const subtotal = calculateSubtotal();
    const total = subtotal + shippingCost;
    document.getElementById('total-step1').textContent = `$${total.toLocaleString()}`;

    return calculatedCost;
}

// Trigger shipping calculation when address changes
document.addEventListener('DOMContentLoaded', () => {
    const addressFields = ['street', 'streetNumber', 'city'];
    addressFields.forEach(fieldId => {
        const field = document.getElementById(fieldId);
        if (field) {
            field.addEventListener('blur', () => {
                const deliveryMethod = document.querySelector('input[name="delivery"]:checked').value;
                if (deliveryMethod === 'shipping') {
                    calculateShipping();
                }
            });
        }
    });
});

// Proceed to payment step
function proceedToPayment() {
    const form = document.getElementById('customer-form');

    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }

    // Collect customer data
    customerData = {
        firstName: document.getElementById('firstName').value,
        lastName: document.getElementById('lastName').value,
        phone: document.getElementById('phone').value,
        deliveryMethod: document.querySelector('input[name="delivery"]:checked').value
    };

    if (customerData.deliveryMethod === 'shipping') {
        customerData.address = {
            street: document.getElementById('street').value,
            number: document.getElementById('streetNumber').value,
            city: document.getElementById('city').value,
            postalCode: document.getElementById('postalCode').value
        };
    }

    // Show step 2
    document.getElementById('step-1').classList.remove('active');
    document.getElementById('step-2').classList.add('active');

    // Update progress indicators
    document.getElementById('step-indicator-1').classList.remove('bg-black');
    document.getElementById('step-indicator-1').classList.add('bg-green-500');
    document.getElementById('step-indicator-2').classList.remove('bg-gray-300', 'text-gray-600');
    document.getElementById('step-indicator-2').classList.add('bg-black', 'text-white');

    // Render step 2 content
    renderPaymentStep();

    // Scroll to top
    window.scrollTo(0, 0);
}

// Render payment step
function renderPaymentStep() {
    // Customer summary
    const customerSummary = `
        <strong>${customerData.firstName} ${customerData.lastName}</strong><br>
        Teléfono: ${customerData.phone}
    `;
    document.getElementById('customer-summary').innerHTML = customerSummary;

    // Delivery summary
    let deliverySummary = '';
    if (customerData.deliveryMethod === 'pickup') {
        deliverySummary = '<strong>Retiro en el local:</strong> San Martín 3062, Santa Fe';
    } else {
        deliverySummary = `
            <strong>Envío a domicilio:</strong><br>
            ${customerData.address.street} ${customerData.address.number}, ${customerData.address.city}
            ${customerData.address.postalCode ? ', CP: ' + customerData.address.postalCode : ''}
        `;
    }
    document.getElementById('delivery-summary').innerHTML = deliverySummary;

    // Order items in sticky sidebar
    const orderItems = document.getElementById('order-items');
    orderItems.innerHTML = cart.map(item => `
        <div class="flex gap-3 pb-3 border-b">
            <img src="${item.image}" alt="${item.name}" class="w-16 h-20 object-cover">
            <div class="flex-1">
                <p class="font-medium text-sm">${item.name}</p>
                <p class="text-xs text-gray-600">Talle: ${item.selectedSize}</p>
                <p class="text-xs">Cant: ${item.quantity}</p>
                <p class="font-bold text-sm">$${(item.price * item.quantity).toLocaleString()}</p>
            </div>
        </div>
    `).join('');

    // Totals
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    document.getElementById('final-subtotal').textContent = `$${subtotal.toLocaleString()}`;

    if (customerData.deliveryMethod === 'shipping' && shippingCost > 0) {
        document.getElementById('final-shipping-row').classList.remove('hidden');
        document.getElementById('final-shipping').textContent = `$${shippingCost.toLocaleString()}`;
    }

    const total = subtotal + shippingCost;
    document.getElementById('final-total').textContent = `$${total.toLocaleString()}`;
}

// Go back to step 1
function goBackToStep1() {
    document.getElementById('step-2').classList.remove('active');
    document.getElementById('step-1').classList.add('active');

    // Update progress indicators
    document.getElementById('step-indicator-1').classList.add('bg-black');
    document.getElementById('step-indicator-1').classList.remove('bg-green-500');
    document.getElementById('step-indicator-2').classList.add('bg-gray-300', 'text-gray-600');
    document.getElementById('step-indicator-2').classList.remove('bg-black', 'text-white');

    window.scrollTo(0, 0);
}

// Select payment method
function selectPayment(method) {
    selectedPaymentMethod = method;

    // Update UI
    document.querySelectorAll('.payment-option').forEach(option => {
        option.classList.remove('selected');
    });
    event.currentTarget.classList.add('selected');
}

// Finalize purchase
function finalizePurchase() {
    if (!selectedPaymentMethod) {
        alert('Por favor selecciona un método de pago');
        return;
    }

    // Prepare order data
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const total = subtotal + shippingCost;

    const orderData = {
        customer: customerData,
        items: cart,
        subtotal: subtotal,
        shipping: shippingCost,
        total: total,
        paymentMethod: selectedPaymentMethod,
        date: new Date().toISOString()
    };

    // Create WhatsApp message
    let message = `🛍️ *NUEVO PEDIDO - AUDAZ*\n\n`;
    message += `👤 *Cliente:* ${customerData.firstName} ${customerData.lastName}\n`;
    message += `📞 *Teléfono:* ${customerData.phone}\n\n`;

    if (customerData.deliveryMethod === 'pickup') {
        message += `📍 *Retiro en el local*\n\n`;
    } else {
        message += `🚚 *Envío a domicilio:*\n`;
        message += `${customerData.address.street} ${customerData.address.number}\n`;
        message += `${customerData.address.city}${customerData.address.postalCode ? ', CP: ' + customerData.address.postalCode : ''}\n`;
        message += `💰 Costo de envío: $${shippingCost.toLocaleString()}\n\n`;
    }

    message += `🛒 *Productos:*\n`;
    cart.forEach(item => {
        message += `• ${item.name} (Talle ${item.selectedSize}) x${item.quantity} - $${(item.price * item.quantity).toLocaleString()}\n`;
    });

    message += `\n💵 *Subtotal:* $${subtotal.toLocaleString()}\n`;
    if (shippingCost > 0) {
        message += `🚚 *Envío:* $${shippingCost.toLocaleString()}\n`;
    }
    message += `💰 *TOTAL:* $${total.toLocaleString()}\n\n`;

    const paymentMethodText = {
        'credit': '💳 Tarjeta de Crédito/Débito',
        'transfer': '🏦 Transferencia Bancaria',
        'mercadopago': '💵 Mercado Pago'
    };
    message += `💳 *Método de pago:* ${paymentMethodText[selectedPaymentMethod]}`;

    // Encode message for WhatsApp
    const whatsappNumber = '5493424000000'; // Replace with actual WhatsApp number
    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodedMessage}`;

    // Clear cart
    localStorage.removeItem('audaz_cart');

    // Redirect to WhatsApp
    window.open(whatsappUrl, '_blank');

    // Show success message and redirect
    setTimeout(() => {
        alert('¡Gracias por tu compra! Te contactaremos pronto por WhatsApp.');
        window.location.href = 'index.html';
    }, 1000);
}
