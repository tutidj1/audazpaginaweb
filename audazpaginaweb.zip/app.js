// Cart state
let cart = JSON.parse(localStorage.getItem('audaz_cart')) || [];

// Save cart to localStorage
function saveCart() {
    localStorage.setItem('audaz_cart', JSON.stringify(cart));
}

// Render products for a specific section
function renderProductSection(containerId, filteredProducts) {
    const container = document.getElementById(containerId);
    if (!container) return;

    if (filteredProducts.length === 0) {
        container.innerHTML = '<p class="text-center w-full text-gray-500 py-4">Próximamente nuevos ingresos</p>';
        return;
    }

    container.innerHTML = filteredProducts.map(product => `
        <div class="product-card fade-in group cursor-pointer min-w-[280px] w-[280px] snap-center flex-shrink-0" onclick="goToProduct(${product.id})">
            <div class="relative aspect-[3/4] bg-gray-100 mb-3 overflow-hidden">
                <img src="${product.image}" 
                     alt="${product.name}" 
                     class="product-img-main w-full h-full object-cover">
                <img src="${product.imageHover}" 
                     alt="${product.name}" 
                     class="product-img-hover w-full h-full object-cover">
                <button onclick="event.stopPropagation(); addToCart(${product.id})" 
                        class="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-black text-white px-6 py-2 uppercase text-sm tracking-wide opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap">
                    Agregar al Carrito
                </button>
            </div>
            <h3 class="text-sm font-medium uppercase tracking-wide mb-1">${product.name}</h3>
            <p class="text-lg font-bold">$${product.price.toLocaleString()}</p>
        </div>
    `).join('');
}

// Render all sections
function renderAllSections() {
    // 1. Ofertas (Simulator: Products with ID < 5 OR specific flag if we had one)
    // For now, let's take some random products
    const ofertas = products.slice(0, 4);
    renderProductSection('grid-ofertas', ofertas);

    // 2. Colección (Remeras, Vestidos, Tops, Bodies)
    const coleccion = products.filter(p => ['Remeras', 'Vestidos', 'Tops', 'Bodies', 'Pantalones'].includes(p.category));
    renderProductSection('grid-coleccion', coleccion);

    // 3. Denim
    const denim = products.filter(p => p.category === 'Denim');
    renderProductSection('grid-denim', denim);

    // 4. Accesorios
    const accesorios = products.filter(p => p.category === 'Accesorios');
    renderProductSection('grid-accesorios', accesorios);
}

// Navigate to product detail page
function goToProduct(productId) {
    window.location.href = `product.html?id=${productId}`;
}

// Add to cart
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    const existingItem = cart.find(item => item.id === productId);

    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({
            ...product,
            quantity: 1,
            selectedSize: product.sizes[0]
        });
    }

    saveCart();
    updateCart();
    showCart();
}

// Update cart UI
function updateCart() {
    const cartCount = document.getElementById('cart-count');
    const cartItems = document.getElementById('cart-items');
    const cartTotal = document.getElementById('cart-total');

    // Update count
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCount.textContent = totalItems;

    // Update items
    cartItems.innerHTML = cart.map(item => `
        <div class="flex justify-between items-center bg-gray-50 p-3 rounded">
            <div>
                <p class="font-medium text-sm">${item.name}</p>
                <p class="text-xs text-gray-500">
                    ${item.selectedSize ? `Talle: ${item.selectedSize} | ` : ''}
                    $${item.price.toLocaleString()} x ${item.quantity}
                </p>
            </div>
            <div class="flex items-center gap-3">
                <p class="font-bold text-sm">$${(item.price * item.quantity).toLocaleString()}</p>
                <button onclick="removeFromCart(${item.id}, '${item.selectedSize}')" class="text-red-500 hover:text-red-700 text-xs">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `).join('');

    // Update total
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    cartTotal.textContent = `$${total.toLocaleString()}`;
}

// Remove from cart
function removeFromCart(productId, size) {
    const index = cart.findIndex(item => item.id === productId && item.selectedSize === size);
    if (index > -1) {
        cart.splice(index, 1);
        saveCart();
        updateCart();
    }
}

// Show/Hide Cart
function showCart() {
    const sidebar = document.getElementById('cart-sidebar');
    const overlay = document.getElementById('cart-overlay');
    sidebar.classList.remove('translate-x-full');
    overlay.classList.remove('translate-x-full', 'opacity-0');
}

function hideCart() {
    const sidebar = document.getElementById('cart-sidebar');
    const overlay = document.getElementById('cart-overlay');
    sidebar.classList.add('translate-x-full');
    overlay.classList.add('translate-x-full', 'opacity-0');
}

// Mobile Menu
function toggleMobileMenu() {
    const menu = document.getElementById('mobile-menu');
    menu.classList.toggle('hidden');
}

// Scroll Section Carousel
function scrollSection(sectionName, direction) {
    const containerId = `grid-${sectionName}`;
    const container = document.getElementById(containerId);
    if (!container) return;

    const scrollAmount = 300;

    if (direction === 'left') {
        container.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
    } else {
        container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
}

// Intersection Observer for animations
const observerOptions = {
    threshold: 0.1
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    // Only verify if we are on index (look for one of the grids)
    if (document.getElementById('grid-coleccion')) {
        renderAllSections();
    }

    updateCart();

    // Observe product cards for animation
    setTimeout(() => {
        document.querySelectorAll('.product-card').forEach(card => {
            observer.observe(card);
        });
    }, 100);
});
