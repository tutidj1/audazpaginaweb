const products = [
    {
        id: 1,
        name: "REMERA BÁSICA NEGRA",
        price: 12000,
        image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&h=600&fit=crop",
        imageHover: "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=500&h=600&fit=crop",
        images: [
            "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1618354691373-d851c5c3a990?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1622445275576-721325763afe?w=500&h=600&fit=crop"
        ],
        colors: [
            { name: "Negro", hex: "#000000" },
            { name: "Blanco", hex: "#FFFFFF" },
            { name: "Gris", hex: "#808080" }
        ],
        category: "Remeras",
        sizes: ["S", "M", "L", "XL"],
        description: "Remera básica de algodón 100%. Corte clásico, perfecta para combinar con cualquier look. Disponible en varios colores.",
        relatedProducts: [7, 4, 10]
    },
    {
        id: 2,
        name: "VESTIDO MIDI BLANCO",
        price: 28000,
        image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=500&h=600&fit=crop",
        imageHover: "https://images.unsplash.com/photo-1612336307429-8a898d10e223?w=500&h=600&fit=crop",
        images: [
            "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1612336307429-8a898d10e223?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1585487000160-6ebcfceb0d03?w=500&h=600&fit=crop"
        ],
        colors: [
            { name: "Blanco", hex: "#FFFFFF" },
            { name: "Negro", hex: "#000000" },
            { name: "Beige", hex: "#F5F5DC" }
        ],
        category: "Vestidos",
        sizes: ["S", "M", "L"],
        description: "Vestido midi elegante, ideal para cualquier ocasión. Tela fluida y cómoda. Diseño atemporal.",
        relatedProducts: [8, 5, 10]
    },
    {
        id: 3,
        name: "SHORT DENIM CLARO",
        price: 18500,
        image: "https://images.unsplash.com/photo-1591195853828-11db59a44f6b?w=500&h=600&fit=crop",
        imageHover: "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=500&h=600&fit=crop",
        images: [
            "https://images.unsplash.com/photo-1591195853828-11db59a44f6b?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1582418702059-97ebafb35d09?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=500&h=600&fit=crop"
        ],
        colors: [
            { name: "Celeste", hex: "#87CEEB" },
            { name: "Azul Oscuro", hex: "#1E3A8A" },
            { name: "Negro", hex: "#000000" }
        ],
        category: "Denim",
        sizes: ["26", "28", "30", "32"],
        description: "Short de jean con roturas. Tiro alto, fit perfecto. Ideal para el verano.",
        relatedProducts: [6, 11, 9]
    },
    {
        id: 4,
        name: "TOP CROP NEGRO",
        price: 9500,
        image: "https://images.unsplash.com/photo-1564859228273-274232fdb516?w=500&h=600&fit=crop",
        imageHover: "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=500&h=600&fit=crop",
        images: [
            "https://images.unsplash.com/photo-1564859228273-274232fdb516?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1554568218-0f1715e72254?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1562137369-1a1a0bc66744?w=500&h=600&fit=crop"
        ],
        colors: [
            { name: "Negro", hex: "#000000" },
            { name: "Blanco", hex: "#FFFFFF" },
            { name: "Rosa", hex: "#FFC0CB" }
        ],
        category: "Tops",
        sizes: ["S", "M", "L"],
        description: "Top crop ajustado. Perfecto para combinar con jeans o polleras. Tela elástica y cómoda.",
        relatedProducts: [10, 1, 5]
    },
    {
        id: 5,
        name: "BODY MANGA LARGA",
        price: 15000,
        image: "https://images.unsplash.com/photo-1539533018447-63fcce2678e3?w=500&h=600&fit=crop",
        imageHover: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=500&h=600&fit=crop",
        images: [
            "https://images.unsplash.com/photo-1539533018447-63fcce2678e3?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1562157873-818bc0726f68?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?w=500&h=600&fit=crop"
        ],
        colors: [
            { name: "Negro", hex: "#000000" },
            { name: "Blanco", hex: "#FFFFFF" },
            { name: "Nude", hex: "#E3BC9A" }
        ],
        category: "Bodies",
        sizes: ["S", "M", "L", "XL"],
        description: "Body de manga larga con cierre en la entrepierna. Ideal para looks ajustados. Tela suave y elástica.",
        relatedProducts: [12, 4, 2]
    },
    {
        id: 6,
        name: "JEAN MOM FIT",
        price: 32000,
        image: "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=500&h=600&fit=crop",
        imageHover: "https://images.unsplash.com/photo-1582418702059-97ebafb35d09?w=500&h=600&fit=crop",
        images: [
            "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1582418702059-97ebafb35d09?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1584370848010-d7fe6bc767ec?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1598554747436-c9293d6a588f?w=500&h=600&fit=crop"
        ],
        colors: [
            { name: "Azul Medio", hex: "#4682B4" },
            { name: "Celeste", hex: "#87CEEB" },
            { name: "Negro", hex: "#000000" }
        ],
        category: "Denim",
        sizes: ["26", "28", "30", "32", "34"],
        description: "Jean mom fit de tiro alto. Corte relajado y cómodo. Estilo vintage moderno.",
        relatedProducts: [11, 3, 9]
    },
    {
        id: 7,
        name: "REMERA OVERSIZE BLANCA",
        price: 13500,
        image: "https://images.unsplash.com/photo-1618354691373-d851c5c3a990?w=500&h=600&fit=crop",
        imageHover: "https://images.unsplash.com/photo-1622445275576-721325763afe?w=500&h=600&fit=crop",
        images: [
            "https://images.unsplash.com/photo-1618354691373-d851c5c3a990?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1622445275576-721325763afe?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=500&h=600&fit=crop"
        ],
        colors: [
            { name: "Blanco", hex: "#FFFFFF" },
            { name: "Negro", hex: "#000000" },
            { name: "Beige", hex: "#F5F5DC" }
        ],
        category: "Remeras",
        sizes: ["S", "M", "L", "XL"],
        description: "Remera oversize de algodón. Corte amplio y relajado. Perfecta para un look casual.",
        relatedProducts: [1, 4, 10]
    },
    {
        id: 8,
        name: "VESTIDO CORTO NEGRO",
        price: 24000,
        image: "https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=500&h=600&fit=crop",
        imageHover: "https://images.unsplash.com/photo-1585487000160-6ebcfceb0d03?w=500&h=600&fit=crop",
        images: [
            "https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1585487000160-6ebcfceb0d03?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1612336307429-8a898d10e223?w=500&h=600&fit=crop"
        ],
        colors: [
            { name: "Negro", hex: "#000000" },
            { name: "Rojo", hex: "#DC143C" },
            { name: "Blanco", hex: "#FFFFFF" }
        ],
        category: "Vestidos",
        sizes: ["S", "M", "L"],
        description: "Vestido corto para salir. Diseño moderno y favorecedor. Ideal para eventos nocturnos.",
        relatedProducts: [2, 5, 12]
    },
    {
        id: 9,
        name: "BERMUDA CARGO",
        price: 21000,
        image: "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=500&h=600&fit=crop",
        imageHover: "https://images.unsplash.com/photo-1591195853828-11db59a44f6b?w=500&h=600&fit=crop",
        images: [
            "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1591195853828-11db59a44f6b?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1582418702059-97ebafb35d09?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=500&h=600&fit=crop"
        ],
        colors: [
            { name: "Verde Militar", hex: "#4B5320" },
            { name: "Negro", hex: "#000000" },
            { name: "Beige", hex: "#F5F5DC" }
        ],
        category: "Shorts",
        sizes: ["S", "M", "L", "XL"],
        description: "Bermuda cargo con bolsillos. Estilo urbano y cómodo. Tela resistente.",
        relatedProducts: [3, 6, 11]
    },
    {
        id: 10,
        name: "TOP HALTER BLANCO",
        price: 11000,
        image: "https://images.unsplash.com/photo-1554568218-0f1715e72254?w=500&h=600&fit=crop",
        imageHover: "https://images.unsplash.com/photo-1562137369-1a1a0bc66744?w=500&h=600&fit=crop",
        images: [
            "https://images.unsplash.com/photo-1554568218-0f1715e72254?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1562137369-1a1a0bc66744?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1564859228273-274232fdb516?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=500&h=600&fit=crop"
        ],
        colors: [
            { name: "Blanco", hex: "#FFFFFF" },
            { name: "Negro", hex: "#000000" },
            { name: "Coral", hex: "#FF7F50" }
        ],
        category: "Tops",
        sizes: ["S", "M", "L"],
        description: "Top halter con escote pronunciado. Perfecto para el verano. Tela fresca y liviana.",
        relatedProducts: [4, 1, 7]
    },
    {
        id: 11,
        name: "JEAN WIDE LEG",
        price: 35000,
        image: "https://images.unsplash.com/photo-1584370848010-d7fe6bc767ec?w=500&h=600&fit=crop",
        imageHover: "https://images.unsplash.com/photo-1598554747436-c9293d6a588f?w=500&h=600&fit=crop",
        images: [
            "https://images.unsplash.com/photo-1584370848010-d7fe6bc767ec?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1598554747436-c9293d6a588f?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1582418702059-97ebafb35d09?w=500&h=600&fit=crop"
        ],
        colors: [
            { name: "Azul Oscuro", hex: "#1E3A8A" },
            { name: "Celeste", hex: "#87CEEB" },
            { name: "Negro", hex: "#000000" }
        ],
        category: "Denim",
        sizes: ["26", "28", "30", "32", "34"],
        description: "Jean wide leg de pierna ancha. Tendencia actual. Tiro alto y cómodo.",
        relatedProducts: [6, 3, 9]
    },
    {
        id: 12,
        name: "BODY STRAPLESS",
        price: 16500,
        image: "https://images.unsplash.com/photo-1562157873-818bc0726f68?w=500&h=600&fit=crop",
        imageHover: "https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?w=500&h=600&fit=crop",
        images: [
            "https://images.unsplash.com/photo-1562157873-818bc0726f68?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1539533018447-63fcce2678e3?w=500&h=600&fit=crop",
            "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=500&h=600&fit=crop"
        ],
        colors: [
            { name: "Negro", hex: "#000000" },
            { name: "Blanco", hex: "#FFFFFF" },
            { name: "Nude", hex: "#E3BC9A" }
        ],
        category: "Bodies",
        sizes: ["S", "M", "L"],
        description: "Body strapless sin tirantes. Ideal para looks elegantes. Ajuste perfecto.",
        relatedProducts: [5, 2, 8]
    }
];
